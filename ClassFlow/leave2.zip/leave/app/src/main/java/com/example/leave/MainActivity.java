package com.example.leave;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;
import android.content.Intent;
import android.util.Log;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.leave.R;
import com.example.leave.TelaPrincipal;

public class MainActivity extends AppCompatActivity {
    EditText edtSenha;
    Button btnEntrar;
    String senhaCorreta = "1234";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando os componentes0
        edtSenha = findViewById(R.id.edtSenha);
        btnEntrar = findViewById(R.id.btnEntrar);
        // Listener para o botão
        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String senhaDigitada = edtSenha.getText().toString();

                // Log para depuração: veja no Logcat o que foi digitado
                Log.d("MainActivity", "Senha digitada: " + senhaDigitada);

                if (senhaDigitada.equals(senhaCorreta)) {
                    // Senha correta → vai para a próxima tela
                    Intent intent = new Intent(MainActivity.this, TelaPrincipal.class);
                    startActivity(intent);
                    finish();  // Fecha a tela de login para impedir voltar
                } else {
                    // Senha errada → mostra mensagem
                    Toast.makeText(MainActivity.this, "Senha incorreta", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
