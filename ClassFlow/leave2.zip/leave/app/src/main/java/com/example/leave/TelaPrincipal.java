package com.example.leave;

public class TelaPrincipal {
}
